from random import randint

def openFile(fn):
    f = open(fn)
    return f.readlines()

def saveFile(fn,arr):
    f = open(fn, 'w')
    f.writelines(arr)

def choose(arr,per):
    count = 0
    rands = []
    other = []
    c = int(per * (len(arr)/100.0))
    for e in arr:
        if count < c:
            rand = randint(0,1)
            if rand == 1:
                count+=1
                rands.append(e)
            else:
                other.append(e)
        else:
                other.append(e)
    
    saveFile("../output/rands"+str(per)+".txt",rands)
    saveFile("../output/other"+str(per)+".txt",other)

australian = openFile("../data/australian.txt")
choose(australian,30)
choose(australian,50)
choose(australian,70)


        